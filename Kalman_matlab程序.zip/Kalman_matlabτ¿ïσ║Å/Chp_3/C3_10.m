clc
clear
t=0.01:0.01:10;
za=[20+sqrt(2)*randn(500,1);30+sqrt(2)*randn(500,1)];
plot(za)