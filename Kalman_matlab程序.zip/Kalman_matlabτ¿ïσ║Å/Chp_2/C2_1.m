%C2_1
clc;
clear;
m=20;
v=8;
s2=m+sqrt(v)*randn(1,1000);
plot(s2)

